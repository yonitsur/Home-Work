package il.ac.tau.cs.sw1.ex2;

public class Assignment02Q03 {

	public static void main(String[] args) {
		int numOfEven = 0;
		int n = -1;
		
		n = Integer.parseInt(args[0]);
		String Fib = "1 1";
		
		int prev = 1;
		int prevPrev = 1;
		int curr = 2;
		
		for (int i = 2 ; i < n ; i++) {
			Fib += " "+curr;
			if (curr%2 == 0) numOfEven++;
			prevPrev = prev;
			prev = curr;
			curr = prev + prevPrev;
			
		}
				
		System.out.println("The first "+ n +" Fibonacci numbers are:");
		System.out.println(Fib);
		System.out.println("The number of even numbers is: "+numOfEven);

	}

}
