package il.ac.tau.cs.sw1.ex5;

import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.File;
import java.util.Arrays;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.FileWriter; 
public class BigramModel {
	public static final int MAX_VOCABULARY_SIZE = 14500;
	public static final String VOC_FILE_SUFFIX = ".voc";
	public static final String COUNTS_FILE_SUFFIX = ".counts";
	public static final String SOME_NUM = "some_num";
	public static final int ELEMENT_NOT_FOUND = -1;
	
	String[] mVocabulary;
	int[][] mBigramCounts;
	
	// DO NOT CHANGE THIS !!! 
	public void initModel(String fileName) throws IOException{
		mVocabulary = buildVocabularyIndex(fileName);
		mBigramCounts = buildCountsArray(fileName, mVocabulary);
		
	}
	/*
	 * @post: mVocabulary = prev(mVocabulary)
	 * @post: mBigramCounts = prev(mBigramCounts)
	 */
	public String[] buildVocabularyIndex(String fileName) throws IOException{ // Q 1
		
		Scanner text = new Scanner(new File(fileName));
		int cnt = 0;
		String str = "#";
		String word = new String();
		
		while (text.hasNext() && cnt<=MAX_VOCABULARY_SIZE) {
			word = text.next().toLowerCase();
			switch (isWhat(word)) {
				case "not legal":
					break;
				case "intiger":
					if (!str.contains("#"+SOME_NUM+"#")) {
						str+=(SOME_NUM+"#");
						cnt++;
					}
					break;
				case "legal word":
					if (!str.contains("#"+ word +"#")) {
						str+=(word + "#");
						cnt++;
					}
					break;
			}
		}
		if (cnt==0) {
			String[] empty= new String[]{};
			return empty;
		}
		String[] splited = str.split("#");
		String[] vocabulary = new String[splited.length-1]	;	
		for (int i = 0; i< vocabulary.length; i++) {
			vocabulary[i] = splited[i+1];
		}
		return vocabulary;
	}
	
	private static String isWhat(String word) {
		int cntL = 0;
		int cntN = 0;
		word = word.toLowerCase();
		for(int i=0; i<word.length(); i++) {
			if(Character.isDigit(word.charAt(i))) 
				cntN++;
			if((int) word.charAt(i)>96 && (int) word.charAt(i)<123) 
				cntL++;
		}
		if (cntN == word.length()) 
			return "intiger";
		if (cntL == 0) 
			return "not legal";
		else
			return "legal word";
		
	}
	/*
	 * @post: mVocabulary = prev(mVocabulary)
	 * @post: mBigramCounts = prev(mBigramCounts)
	 */
	public int[][] buildCountsArray(String fileName, String[] vocabulary) throws IOException{ // Q - 2
		int[][] bigramCounts = new int[vocabulary.length][vocabulary.length];
		
		for(int i = 0; i<vocabulary.length; i++)
			for(int j = 0; j<vocabulary.length; j++)
				bigramCounts[i][j] = count(fileName, vocabulary[i], vocabulary[j]);
		
		return bigramCounts;
	}
	
	private static int count(String fileName, String word1, String word2) throws IOException {
		int cnt = 0;
		Scanner text = new Scanner(new File(fileName));
		while (text.hasNextLine()) {
			String[] arr = text.nextLine().split(" ");			
			for(int i=0; i<arr.length-1; i++) {
				if((word1.equals(SOME_NUM) && isWhat(arr[i].toLowerCase()).equals("intiger") && arr[i+1].toLowerCase().equals(word2)) || 
					(word2.equals(SOME_NUM) && arr[i].toLowerCase().equals(word1) && isWhat(arr[i+1].toLowerCase()).equals("intiger")) || 
					(arr[i].toLowerCase().equals(word1) && arr[i+1].toLowerCase().equals(word2)))
						cnt++;	
			}
		}
		return cnt;
	}
	/*
	 * @pre: the method initModel was called (the language model is initialized)
	 * @pre: fileName is a legal file path
	 */
	public void saveModel(String fileName) throws IOException{ // Q-3
		File voc = new File(fileName+VOC_FILE_SUFFIX);
		File counts = new File(fileName+COUNTS_FILE_SUFFIX);
		voc.createNewFile();
		counts.createNewFile();
		FileWriter vocWriter = new FileWriter(fileName+VOC_FILE_SUFFIX);
		FileWriter countsWriter = new FileWriter(fileName+COUNTS_FILE_SUFFIX);
		vocWriter.write(this.mVocabulary.length + " words"+"\n");
		for (int i=0; i<this.mVocabulary.length; i++) {
			vocWriter.write(i+","+this.mVocabulary[i]+"\n");
		}
		vocWriter.close();
		for (int i=0; i<this.mBigramCounts.length; i++) {
			for (int j=0; j<this.mBigramCounts.length; j++) {
				if(this.mBigramCounts[i][j] != 0) {
					countsWriter.write(i+","+j+":"+mBigramCounts[i][j]+"\n");
				}
			}
		}
		countsWriter.close();
	}
	
	/*
	 * @pre: fileName is a legal file path
	 */
	public void loadModel(String fileName) throws IOException{ // Q - 4
		Scanner vocScanner = new Scanner(new File(fileName+VOC_FILE_SUFFIX));
		Scanner countsScanner = new Scanner(new File(fileName+COUNTS_FILE_SUFFIX));
		int len = vocScanner.nextInt();
		String[] Voc = new String[len];
		int[][] Cnt = new int[len][len];
		vocScanner.nextLine();
		while(vocScanner.hasNextLine()) {
			String[] arr = vocScanner.nextLine().split(",");
			Voc[Integer.parseInt(arr[0])] = arr[1];
		}
		this.mVocabulary = Voc;
		while(countsScanner.hasNext()) {
			String[] arr1 = countsScanner.next().split(":");
			String[] arr2 = arr1[0].split(",");
			Cnt[Integer.parseInt(arr2[0])][Integer.parseInt(arr2[1])]= Integer.parseInt(arr1[1]); 
		}
		this.mBigramCounts = Cnt;
	}
	/*
	 * @pre: word is in lowercase
	 * @pre: the method initModel was called (the language model is initialized)
	 * @pre: word is in lowercase
	 * @post: $ret = -1 if word is not in vocabulary, otherwise $ret = the index of word in vocabulary
	 */
	public int getWordIndex(String word){  // Q - 5
		for(int i=0; i<this.mVocabulary.length; i++) 
			if(this.mVocabulary[i].equals(word)) 
				return i;	
		return ELEMENT_NOT_FOUND;
	}
	
	/*
	 * @pre: word1, word2 are in lowercase
	 * @pre: the method initModel was called (the language model is initialized)
	 * @post: $ret = the count for the bigram <word1, word2>. if one of the words does not
	 * exist in the vocabulary, $ret = 0
	 */
	public int getBigramCount(String word1, String word2){ //  Q - 6
		int x = getWordIndex(word1);
		int y = getWordIndex(word2);
		if( x == ELEMENT_NOT_FOUND || y == ELEMENT_NOT_FOUND)
			return 0;
		return this.mBigramCounts[x][y];
	}
	/*
	 * @pre word in lowercase, and is in mVocabulary
	 * @pre: the method initModel was called (the language model is initialized)
	 * @post $ret = the word with the lowest vocabulary index that appears most fequently after word (if a bigram starting with
	 * word was never seen, $ret will be null
	 */
	public String getMostFrequentProceeding(String word){ //  Q - 7
		int x = getWordIndex(word);
		int max = 0;
		int index = 0;
		for(int i=0; i<this.mVocabulary.length; i++) 
			if(this.mBigramCounts[x][i]>max) {
				max = this.mBigramCounts[x][i];
				index = i;
			}
		if(max == 0)
			return null;
		return this.mVocabulary[index];
	}
	
	/* @pre: sentence is in lowercase
	 * @pre: the method initModel was called (the language model is initialized)
	 * @pre: each two words in the sentence are are separated with a single space
	 * @post: if sentence is is probable, according to the model, $ret = true, else, $ret = false
	 */
	public boolean isLegalSentence(String sentence){  //  Q - 8
		String[] arr = sentence.split(" ");
		if (arr.length == 1) {
			if(getWordIndex(arr[0])!=ELEMENT_NOT_FOUND)
				return true; 
			return false;
		}
		for(int i = 0 ; i<arr.length-1; i++ ) {
			if(getBigramCount(arr[i], arr[i+1]) == 0) 
				return false;
		}	
		return true;
	}
	
	/*
	 * @pre: arr1.length = arr2.legnth
	 * post if arr1 or arr2 are only filled with zeros, $ret = -1, otherwise calcluates CosineSim
	 */
	public static double calcCosineSim(int[] arr1, int[] arr2){ //  Q - 9
		int mone = 0;
		double mechane = 0;
		int a = 0;
		int b = 0;
		for(int i = 0; i< arr1.length; i++) {
			mone += (arr1[i]*arr2[i]);
			a+=(arr1[i]*arr1[i]);
			b+=(arr2[i]*arr2[i]);
		}
		mechane = Math.sqrt(a)*Math.sqrt(b);
		if (mechane==0) {
			return -1;
		}
		return (mone/mechane);
	}

	/*
	 * @pre: word is in vocabulary
	 * @pre: the method initModel was called (the language model is initialized), 
	 * @post: $ret = w implies that w is the word with the largest cosineSimilarity(vector for word, vector for w) among all the
	 * other words in vocabulary
	 */
	public String getClosestWord(String word){ //  Q - 10
		int[] wordArr = this.mBigramCounts[getWordIndex(word)];
		double tmp = 0;
		double max = 0;
		int index = 0;
		for(int i=0; i<this.mVocabulary.length; i++) {
			if (i!=getWordIndex(word)) {
				tmp = calcCosineSim(wordArr, this.mBigramCounts[i]);
				if(tmp>max) {
					max = tmp;
					index = i;
				}
			}
		}
		return this.mVocabulary[index];
	}
	
	
	/*
	 * @pre: word is a String
	 * @pre: the method initModel was called (the language model is initialized)
	 * @post: $ret = the number of word's occurrences in the text.
	 */
	public int getWordCount(String word){ //  Q - 11
		int sum1 = 0;
		int sum2 = 0;
		int index = getWordIndex(word);
		if(index==ELEMENT_NOT_FOUND)
			return 0;
		for(int i = 0; i<this.mVocabulary.length; i++) {
				sum1+=this.mBigramCounts[i][index];
				sum2+=this.mBigramCounts[index][i];
		    }
		return Math.max(sum1, sum2);
	
	}
	
	
}
