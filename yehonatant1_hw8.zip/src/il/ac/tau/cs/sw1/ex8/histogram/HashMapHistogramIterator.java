package il.ac.tau.cs.sw1.ex8.histogram;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Comparator;
import java.util.NoSuchElementException;
import java.util.Set;
/**************************************
 *  Add your code to this class !!!   *
 **************************************/
public class HashMapHistogramIterator<T extends Comparable<T>> implements Iterator<T>{
	private HashMap<T, Integer> map;
	private Set<T> lst;
	
	
	public HashMapHistogramIterator(HashMap<T, Integer> Hmap, Set<T> keys) {
		map = Hmap;
		lst = keys;
	}
		
	@Override
	public boolean hasNext() {
		if(lst.isEmpty())
			return false; 
		return true;
	}

	@Override
	public T next() {
		if (!hasNext()) 
			throw new NoSuchElementException();
		int max = 0;
		T next = null;
		for (T key : lst) {
			if(map.get(key) > max) {
				max = map.get(key);
				next = key;
			}
			if(map.get(key) == max) 
				if(new Compare().compare(key, next)<0) 
					next = key;
		}
		lst.remove(next);
		return next;
	}

	@Override
	public void remove() {
		throw new UnsupportedOperationException(); //no need to change this
	}
	public class Compare implements Comparator<T>{
		public int compare(T e1, T e2) {
			return e1.compareTo(e2);
		}
	}
}
