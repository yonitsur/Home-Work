package il.ac.tau.cs.sw1.hw6;

import java.util.Arrays;

public class Polynomial {
	private double[] coef;
	private int degree;
	
	/*
	 * Creates the zero-polynomial with p(x) = 0 for all x.
	 */
	public Polynomial()
	{
		coef = new double[] {0};
		degree = 0;
	} 
	/*
	 * Creates a new polynomial with the given coefficients.
	 */
	public Polynomial(double[] coefficients) 
	{
		if(coefficients.length == 0) {
			coef = new double[] {0};
			degree = 0; 
		}
		else {
			while(coefficients[coefficients.length - 1] == 0) {
				double[] arr = new double[coefficients.length - 1];
				for(int i=0; i<arr.length; i++) {
					arr[i]=coefficients[i];
				}
				coefficients = arr;
			}
			coef = coefficients;
			degree = coefficients.length-1;
		}
		
	}
	
	public void PrintPolynom() {
		String P= new String();
		if (this.coef[0] < 0.0)
			P += this.coef[0];
		else if(this.coef[0]>0.0)
			P +="+"+ this.coef[0];
		for(int i=1; i<this.coef.length; i++) {
			if(this.coef[i]>0) {
				P+=("+"+this.coef[i]+"*(X^"+i+")");
			}
			else if(this.coef[i]<0.0)
				P+=(this.coef[i]+"*(X^"+i+")");
		}
		System.out.println(P);
	}
	
	/*
	 * Addes this polynomial to the given one
	 *  and retruns the sum as a new polynomial.
	 */
	public Polynomial adds(Polynomial polynomial)
	{
		int maxLen= Math.max(polynomial.degree+1, this.degree+1);
		int minLen= Math.min(polynomial.degree+1, this.degree+1);
		boolean bool = (maxLen == this.degree+1); 		
		double[] sum = new double[maxLen];
		for(int i = 0; i<maxLen; i++) {
			if(i<minLen) 
				sum[i]=polynomial.coef[i]+this.coef[i];
			else if(bool) 
				sum[i]=this.coef[i];
			else 
				sum[i]=polynomial.coef[i];
		}
		
		Polynomial p = new Polynomial(sum);
		return p;
		
	}
	/*
	 * Multiplies a to this polynomial and returns 
	 * the result as a new polynomial.
	 */
	public Polynomial multiply(double a)
	{
		double[] arr = new double[this.coef.length];
		for(int i=0; i<this.coef.length; i++) {
			arr[i]= this.coef[i]*a;
		}
		Polynomial p = new Polynomial(arr);
		return p;
		
	}
	/*
	 * Returns the degree (the largest exponent) of this polynomial.
	 */
	public int getDegree()
	{
		return this.degree;
	}
	/*
	 * Returns the coefficient of the variable x 
	 * with degree n in this polynomial.
	 */
	public double getCoefficient(int n)
	{
		if (n>this.degree)
			return 0.0;
		return this.coef[n];
	}
	
	/*
	 * set the coefficient of the variable x 
	 * with degree n to c in this polynomial.
	 * If the degree of this polynomial < n, it means that that the coefficient of the variable x 
	 * with degree n was 0, and now it will change to c. 
	 */
	public void setCoefficient(int n, double c)
	{
		if (n>this.degree) {
			double[] newCoef = new double[n+1];
			for(int i=0 ; i<this.coef.length; i++) {
				newCoef[i]=this.coef[i];
			}
			newCoef[n]=c;
			this.coef = newCoef;
			this.degree=n;
			return;
		}
		this.coef[n]=c;
		
	}
	
	/*
	 * Returns the first derivation of this polynomial.
	 *  The first derivation of a polynomal a0x0 + ...  + anxn is defined as 1 * a1x0 + ... + n anxn-1.
	
	 */
	public Polynomial getFirstDerivation()
	{
		double[] arr = new double[this.degree];
		for(int i=0; i<arr.length; i++) {
			arr[i]=(i+1)*this.coef[i+1];
		}
		Polynomial p = new Polynomial(arr);
		return p;
	}
	
	/*
	 * given an assignment for the variable x,
	 * compute the polynomial value
	 */
	public double computePolynomial(double x)
	{
		double comp = 0;
		for(int i=0; i<this.coef.length; i++) {
			comp+=(this.coef[i]*(Math.pow(x, i)));
		}
		return comp;
	}
	
	/*
	 * given an assignment for the variable x,
	 * return true iff x is an extrema point (local minimum or local maximum of this polynomial)
	 * x is an extrema point if and only if The value of first derivation of a polynomal at x is 0
	 * and the second derivation of a polynomal value at x is not 0.
	 */
	public boolean isExtrema(double x)
	{
		Polynomial firstDeriv = this.getFirstDerivation();
		Polynomial secondDeriv = firstDeriv.getFirstDerivation();
		if((firstDeriv.computePolynomial(x) == 0) && (secondDeriv.computePolynomial(x) != 0)) {
			return true;
		}
		return false;
		
	}
	
	
	
	public static void main(String[] args) {
			
			double[] arr1 = new double[]{1,2,3};
			double[] arr2 = new double[]{-1,2,3,-4,5};
			Polynomial p1 = new Polynomial(arr1); 
			Polynomial p2 = new Polynomial(arr2);
			//p2.PrintPolynom();
			//System.out.println(p2.computePolynomial(2));
			double y=1/3;
			double[] arr3 = new double[]{0,1,1,y};
			Polynomial p3 = new Polynomial(arr3); 
			p3.PrintPolynom();
			System.out.println(Arrays.toString(p3.coef));
			p1 = p3.getFirstDerivation();
			System.out.println(Arrays.toString(p1.coef));
			/*
			System.out.println(p3.getDegree());
			System.out.println(Arrays.toString(p3.coef));
			PrintPolynom(p3.multiply(2));
			System.out.println(Arrays.toString(p3.multiply(2).coef));
			PrintPolynom(p3);
			p3.setCoefficient(8, 13);
			System.out.println(Arrays.toString(p3.coef));
			PrintPolynom(p3);
			PrintPolynom(p3.getFirstDerivation());
			System.out.println(Arrays.toString(p3.getFirstDerivation().coef));
			PrintPolynom(p3);
			System.out.println(Arrays.toString(p3.coef));
			System.out.println(p3.computePolynomial(1));
	} */
	}
    

}
