package il.ac.tau.cs.sw1.ex2;

public class Assignment02Q01 {

	public static void main(String[] args) {
			for (String str: args) {
				int ascii = (int) str.charAt(0);
				if ((ascii % 3 == 0)&&(ascii % 2 == 0)){
					System.out.println(str.charAt(0));
				}
			}
	}
}
