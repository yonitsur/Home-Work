package il.ac.tau.cs.sw1.hw3;

import java.util.Arrays;

public class StringUtils {

	public static String findSortedSequence(String str) {
		int max = 1;
		int index = 0;
		String[] words = str.split(" ");
		if(words.length==1) return str;
		for (int i=0; i< words.length; i++) {
			int cnt = 1;
			for(int j = i+1; j<words.length; j++) {
				if(isSorted(words[j], words[j-1]))
					cnt+=1;	
				else 
					break;
			}
			if(cnt>=max) {
				max = cnt;
				index = i;
			}
		}		
		String x = new String();
		for (int k=index; k<index+max; k++) {
			x+=words[k];
			if (k<index+max-1) x+=" ";
			}
		return x; 
	}
	
	private static boolean isSorted(String sec, String fir) {
		int i = 0;
		while(i < Math.min(sec.length(), fir.length())) {
			if(sec.charAt(i)>fir.charAt(i)) 
				return true;
			if(sec.charAt(i)<fir.charAt(i)) 
				return false;
			i++;
		}
		if (sec.length()<fir.length()) 
			return false;
		return true;
	}

	public static boolean isAnagram(String a, String b) {
		a=a.toLowerCase();
		b=b.toLowerCase();
		int[] x= new int[26];
		int[] y= new int[26];
		
		for (int i=0; i<a.length(); i++) 
			if((int) a.charAt(i) != 32) 
				x[((int) a.charAt(i))-97]+=1;
		
		for (int i=0; i<b.length(); i++) 
			if((int) b.charAt(i) != 32) 
				y[((int) b.charAt(i))-97]+=1;
		
		return Arrays.toString(x).equals(Arrays.toString(y)); 
	}
	
	public static boolean isEditDistanceOne(String a, String b){
		if(a.equals(b)) 
			return true;
		if(Math.abs(a.length()-b.length())>1) 
			return false;
	
		int cnt = 0;
		if (a.length()==b.length()) {
			for(int i = 0; i<a.length(); i++) 
				if(a.charAt(i)!=b.charAt(i)) {
					cnt++;
					if(cnt>1) 
						return false;
				}
			return true;
		}
		String maxStr = a.length()-b.length()>0?a:b;
		String minStr = a.length()-b.length()>0?b:a;
		for(int i=0; i<minStr.length(); i++) {
			if(minStr.charAt(i)!=maxStr.charAt(i) && maxStr.charAt(i+1)!=minStr.charAt(i)) 
				return false;
		}
		return true; 
	}	
}
