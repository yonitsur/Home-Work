package il.ac.tau.cs.software1.ip;

import java.util.Arrays;

public class IPAddressString implements IPAddress {
	
	private String add;

	IPAddressString(String address) {
		add=address;
	}

	@Override
	public String toString() {
		return add;
	}

	@Override
	public boolean equals(IPAddress other) {
		String str = other.toString();
		if(add.equals(str))
			return true;
		return false;
	}

	@Override
	public int getOctet(int index) {
		String str= new String();
		int cnt = 0;
		for (int i = 0; i<add.length(); i++){
			if(cnt == index) {
				while(i<add.length() && add.charAt(i) != '.') {
					str+=add.charAt(i);
					i++;	
				}
				break;
			}
			else if(add.charAt(i)=='.') {
				cnt++;
			}
		}
		return Integer.parseInt(str);
	}
	@Override
	public boolean isPrivateNetwork(){
		if(this.getOctet(0)==10) 
			return true;
		if(this.getOctet(0)==172 && this.getOctet(1)>=16 && this.getOctet(1)<=31)
			return true;
		if(this.getOctet(0)==192 && this.getOctet(1)==168)
			return true;
		if(this.getOctet(0)==169 && this.getOctet(1)==254)
			return true;
		return false;	
			
		}
	}