package il.ac.tau.cs.sw1.ex4;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.io.File;
public class WordPuzzle {
	public static final char HIDDEN_CHAR = '_';
	public static final int MAX_VOCABULARY_SIZE = 3000;
	//#1
	public static String[] scanVocabulary(Scanner scanner) { // Q - 1
		String str ="#";
		String next = new String();
		scanner.useDelimiter(" ");
		int cnt = 0;
		while (scanner.hasNext() && cnt<=MAX_VOCABULARY_SIZE) {
			next = scanner.next();
			next = next.toLowerCase();
			if (isLegal(next) && !(str.contains("#"+next+"#"))) {
					str+=next;
					str+="#";
					cnt+=1;
			}
		}
		if (cnt==0) {
			String[] empty= {};
			return empty;
		}
		String[] splited = str.split("#");
		String[] vocabulary = new String[splited.length-1]	;	
		for (int i = 0; i< vocabulary.length; i++) {
			vocabulary[i] = splited[i+1];
		}
		vocabulary = LexSort(vocabulary);
		
		return vocabulary;
	}
	
	private static boolean isLegal(String word) {
		if (word.length()<2)
			return false;
		for (int i=0; i<word.length(); i++) {
			if((int) word.charAt(i)<97 || (int) word.charAt(i)>122 ) {
				return false;
			}
		}
		return true;
	}
	
	private static String[] LexSort(String[] arr) {
		int len= arr.length;
		String tmp= new String();
		boolean notSorted;
		do {
			notSorted = false;
			len-=1;
			for(int i=0; i<len; i++) {
				if((isBigger(arr[i], arr[i+1]))) {
					tmp = arr[i];
					arr[i]=arr[i+1];
					arr[i+1]=tmp;
					notSorted = true;
				}
			}
		}while(notSorted);
		
			return arr;
		}
		
	private static boolean isBigger(String sec, String fir) {
		for(int i=0; i< Math.min(sec.length(), fir.length()); i++) {
			if(sec.charAt(i)>fir.charAt(i)) 
				return true;
			if(sec.charAt(i)<fir.charAt(i)) 
				return false;
		}
		if (sec.length()<fir.length()) 
			return false;
		return true;
	}
	//#2
	public static int countHiddenInPuzzle(char[] puzzle) { // Q - 2
		int cnt = 0;
		for(char c: puzzle) {
			if(c == HIDDEN_CHAR) 
				cnt++;				
		}
		return cnt;
	}
	//#3
	public static String getRandomWord(String[] vocabulary, Random generator) { // Q - 3
		return vocabulary[generator.nextInt(vocabulary.length)];
	}
	//#4
	public static boolean checkLegal(String word, char[] puzzle) { // Q - 4
		String covered = new String();
		boolean hidden = false;;
		for(int i=0; i<word.length(); i++) {
			if(word.charAt(i) == puzzle[i]) {
				if(covered.contains(String.valueOf(word.charAt(i)))) {
					return false;
				}
			}
			else {
				covered+=word.charAt(i);
				hidden = true;
			}		
		}
		for(char ch: puzzle) {
			if(covered.contains(String.valueOf(ch))) {
				return false;
			}
		}
		if(covered.length()<word.length() && hidden) {
			return true;
		}
		return false;
	}
	//#5
	public static char[] getRandomPuzzleCandidate(String word, double prob, Random generator) { // Q - 5
		float randomFloat = 0;
		char[] puzzle = new char[word.length()];
		for (int i = 0; i<word.length(); i++) {
			randomFloat = generator.nextFloat();
			if(randomFloat<=prob) {
				puzzle[i] = '_';
			}
			else {
				puzzle[i] = word.charAt(i);
			}
		}
		return puzzle;
	}
	//#6
	public static char[] getRandomPuzzle(String word, double prob, Random generator) { // Q - 6
		int cnt = 0;
		char[] puzzle1 = new char[word.length()];
		do {
			puzzle1 = getRandomPuzzleCandidate(word, prob, generator);
			if(checkLegal(word, puzzle1)) 
				return puzzle1;
			else 
				cnt++;
		}while(cnt<1000);
		throwPuzzleGenerationException();
		return null;
	}
	//#7
	public static int applyGuess(char guess, String solution, char[] puzzle) { // Q - 7
		int cnt = 0;
		for(int i=0; i<solution.length(); i++) {
			if(solution.charAt(i) == guess && puzzle[i]=='_') {
					puzzle[i]=guess;
					cnt++;
			}
		}
		return cnt;
	}
	//#8
	public static char[] getHelp(String solution, char[] puzzle) { // Q - 8
		for (int i = 0; i<solution.length(); i++) {
			if(puzzle[i]=='_') {
				applyGuess(solution.charAt(i),solution, puzzle);
				break;
			}
		}
		return puzzle;
	}
	//#9           ////////////////////////////////////////////////////////         src/resources/hw4/vocabulary.txt  src/resources/hw4/blackbird.txt
	public static void main(String[] args) throws Exception { // Q - 9
		//int vocabularySize = -1; // Replace -1 with size of vocabulary.
		Random generator = new MyRandom(new int[]{0,1,2,3,4,5},new float[]{0.0f,0.1f,0.2f,0.3f,0.4f,0.5f,0.6f,0.7f,0.8f,0.9f,1.0f});
		// Random generator = new MyRandom(getRrandomIntArr(vocabularySize), getRandomFloatArr());
		//Random generator = new Random ();
		boolean bool = true;
		boolean boolbool=true;;
		char[] puzzle = null;
		String answer = new String();
		
		if (args.length != 1) {
			System.out.println("Invaild argument\nGood Bye :)");
			return;
		}
		
		Scanner adress = new Scanner(new File(args[0]));
		String[] vocabulary = WordPuzzle.scanVocabulary(adress);
		printReadVocabulary(args[0], vocabulary.length);
		printSettingsMessage(); 
		while(boolbool) {
			printEnterHidingProbability();
			Scanner P = new Scanner(System.in);
			float prob = P.nextFloat();
			String word = getRandomWord(vocabulary, generator);
			char[] puzzle1 = getRandomPuzzle(word, prob, generator);
			printPuzzle(puzzle1);
			while(bool) {
				printReplacePuzzleMessage();
				Scanner S = new Scanner(System.in);
				String replace = S.next();
				if (replace.equals("no")) {
					answer = word;
					puzzle = puzzle1;
					boolbool = false;
					break;
				}
				else if (replace.equals("yes")) 
						break;
			}
		}
		
		printGameStageMessage();
		printPuzzle(puzzle);
		int _num = countHiddenInPuzzle(puzzle);
		int attempts = _num + 3;
		
		while(attempts>0) {
			printEnterYourGuessMessage();
			Scanner G = new Scanner(System.in);
			char guess = G.next().charAt(0);
			int goodGuesses = applyGuess(guess, answer, puzzle);
			if(goodGuesses == _num) {
				printWinMessage();
				return;
				}
			else {
				if(goodGuesses == 0) {
					if(guess!='H') {
						attempts-=1;
						printWrongGuess(attempts);
						if (attempts == 0) break;
						printPuzzle(puzzle);
					}
					else {
						attempts-=1;
						puzzle = getHelp(answer, puzzle);
						_num = countHiddenInPuzzle(puzzle);
						if (_num==0) {
							printWinMessage();
							return;
						}
						printPuzzle(puzzle);
					}
				}
				else {
					attempts-=1;
					_num = countHiddenInPuzzle(puzzle);
					printCorrectGuess(attempts);
					printPuzzle(puzzle);
				}
			}
		}
		printGameOver();
	}
	

	/*************************************************************/
	/********************* Don't change this ********************/
	/*************************************************************/
	private static float[] getRandomFloatArr() {
		Double[] doubleArr = new Double[] { 0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0 };
		List<Double> doubleList = Arrays.asList(doubleArr);
		Collections.shuffle(doubleList);
		double[] unboxed = doubleList.stream().mapToDouble(Double::doubleValue).toArray();

		// cast double array to float array
		float[] floatArr = new float[unboxed.length];
		for (int i = 0; i < unboxed.length; i++) {
			floatArr[i] = (float) unboxed[i];
		}
		return floatArr;
	}

	private static int[] getRrandomIntArr(int vocabularySize) {
		
		if(vocabularySize<0) {
			throw new RuntimeException("Wrong use of getRandomIntArr(int vocabularySize)");
		}
		
		int i = 0;
		Integer[] intArr = new Integer[vocabularySize];
		while (i < vocabularySize) {
			intArr[i] = i;
			i++;
		}
		List<Integer> doubleList = Arrays.asList(intArr);
		Collections.shuffle(doubleList);
		int[] unboxed = doubleList.stream().mapToInt(Integer::intValue).toArray();
		return unboxed;
	}

	public static void throwPuzzleGenerationException() {
		throw new RuntimeException("Failed creating a legal puzzle after 1000 attempts!");
	}

	public static void printReadVocabulary(String vocabularyFileName, int numOfWords) {
		System.out.println("Read " + numOfWords + " words from " + vocabularyFileName);
	}

	public static void printSettingsMessage() {
		System.out.println("--- Settings stage ---");
	}

	public static void printEnterHidingProbability() {
		System.out.println("Enter your hiding probability:");
	}

	public static void printPuzzle(char[] puzzle) {
		System.out.println(puzzle);
	}

	public static void printReplacePuzzleMessage() {
		System.out.println("Replace puzzle?");
	}

	public static void printGameStageMessage() {
		System.out.println("--- Game stage ---");
	}

	public static void printEnterYourGuessMessage() {
		System.out.println("Enter your guess:");
	}

	public static void printCorrectGuess(int attemptsNum) {
		System.out.println("Correct Guess, " + attemptsNum + " guesses left");
	}

	public static void printWrongGuess(int attemptsNum) {
		System.out.println("Wrong Guess, " + attemptsNum + " guesses left");
	}

	public static void printWinMessage() {
		System.out.println("Congratulations! You solved the puzzle");
	}

	public static void printGameOver() {
		System.out.println("Game over!");
	}

}
