package il.ac.tau.cs.sw1.ex8.wordsRank;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;
import il.ac.tau.cs.sw1.ex8.histogram.HashMapHistogram;
import il.ac.tau.cs.sw1.ex8.histogram.IHistogram;
import il.ac.tau.cs.sw1.ex8.wordsRank.RankedWord.rankType;

/**************************************
 *  Add your code to this class !!!   *
 **************************************/

public class FileIndex {
	
	public static final int UNRANKED_CONST = 30;
	private Map<String, IHistogram<String>> filesMaps = new HashMap<String, IHistogram<String>>();
	private Map<String, Map<String, Integer>> wordsRanksForFiles = new HashMap<String, Map<String, Integer>>();
	private Set<String> allWords = new HashSet<String>();	

	/* 
	 * @pre: the directory is no empty, and contains only readable text files
	 */
  	public void indexDirectory(String folderPath) {
 
		File folder = new File(folderPath);
		File[] listFiles = folder.listFiles();
		
		for (File file : listFiles) 
			if (file.isFile()) {
				try {
					List<String> wordsList = FileUtils.readAllTokens(file);
					IHistogram<String> wordsHist = new HashMapHistogram<>();
					wordsHist.addAll(wordsList);
					filesMaps.put(file.getName(), wordsHist);
				}
				catch(Exception e) {}				
			}
		
		for(IHistogram<String> hist: filesMaps.values()) 
			allWords.addAll(hist.getItemsSet());
		
		for(String word: allWords) {
			Map<String, Integer> rankMap = new HashMap<String, Integer>();
			for(String fileName:filesMaps.keySet()) {
				try {
					rankMap.put(fileName, getRankForWordInFile(fileName, word));
				}
				catch(Exception e) {}
			}
			wordsRanksForFiles.put(word, rankMap);
		}
	}
	
  	/* 
	 * @pre: the index is initialized
	 * @pre filename is a name of a valid file
	 * @pre word is not null
	 */
	public int getCountInFile(String filename, String word) throws FileIndexException{
		if(!filesMaps.keySet().contains(filename)) 
			throw new FileIndexException(filename);
		word = word.toLowerCase();
		IHistogram<String> wordHist = filesMaps.get(filename);
		return wordHist.getCountForItem(word); 
	}
	
	/* 
	 * @pre: the index is initialized
	 * @pre filename is a name of a valid file
	 * @pre word is not null
	 */
	public int getRankForWordInFile(String filename, String word) throws FileIndexException{
		if(!filesMaps.keySet().contains(filename)) 
			throw new FileIndexException(filename);
		word = word.toLowerCase();
		IHistogram<String> wordHist = filesMaps.get(filename);
		if(wordHist.getCountForItem(word)==0)
			return wordHist.getItemsSet().size() + UNRANKED_CONST;
		int rank = 1;
		Iterator<String> it = wordHist.iterator();
		while(it.hasNext() && !it.next().equals(word)) 
			rank++;
		return rank; 
	}
	
	/* 
	 * @pre: the index is initialized
	 * @pre word is not null
	 */
	public int getAverageRankForWord(String word){
		word = word.toLowerCase();
		RankedWord rankedWord = new RankedWord(word, wordsRanksForFiles.get(word));
		return rankedWord.getRankByType(rankType.average);
	}
	
	
	public List<String> getWordsWithAverageRankSmallerThanK(int k){
		return corporated(k, rankType.average);
	}
		
	public List<String> getWordsWithMinRankSmallerThanK(int k){
		return corporated(k, rankType.min);
	}
	
	public List<String> getWordsWithMaxRankSmallerThanK(int k){
		return corporated(k, rankType.max);
	}
	
	
	public List<String> corporated(int k, rankType rType ){
		List<RankedWord> rwList = new LinkedList<RankedWord>();
		for(String word: allWords) 
			rwList.add(new RankedWord(word, wordsRanksForFiles.get(word)));
		rwList.sort(new RankedWordComparator(rankType.min));
		List<String> strList = new LinkedList<>();
		for(RankedWord RW: rwList) 
			if(RW.getRankByType(rType)<k)
				strList.add(RW.getWord());
		return strList;
	}

}
