package il.ac.tau.cs.software1.predicate;

public class Discount implements Action<Book> {
	private double per;
	public Discount(double percentage) { // Q3
		per = percentage;
	}
	
	
	@Override
	public void performAction(Book book) { // Q3
		book.setPrice((per/100)*book.getPrice());
	}
	
}
