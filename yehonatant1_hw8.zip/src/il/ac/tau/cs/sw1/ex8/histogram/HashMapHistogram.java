package il.ac.tau.cs.sw1.ex8.histogram;

import java.util.*;

/**************************************
 *  Add your code to this class !!!   *
 **************************************/
public class HashMapHistogram<T extends Comparable<T>> implements IHistogram<T>{
	
	private HashMap<T, Integer> map = new HashMap<T, Integer>();
	
	@Override
	public Set<Map.Entry<T, Integer>> getMap() {
		return  map.entrySet();
	}

	@Override
	public Iterator<T> iterator() {
		return new HashMapHistogramIterator<T>(map , getItemsSet() );
	}

	@Override
	public void addItem(T item) {
		int X = getCountForItem(item);
		map.put(item, X+1);
	}

	@Override
	public void removeItem(T item) throws IllegalItemException {
		int X = getCountForItem(item);
		if(X==0) throw new IllegalItemException();
		else map.put(item, X-1);
	}

	@Override
	public void addItemKTimes(T item, int k) throws IllegalKValueException {
		if (k<1) throw new IllegalKValueException(k);
		else for(int i=0; i<k; i++) {
				addItem(item);
			}
	}

	@Override
	public void removeItemKTimes(T item, int k) throws IllegalItemException, IllegalKValueException {
		int X = getCountForItem(item);
		if(X==0) throw new IllegalItemException();
		else if(k>X || k<1) throw new IllegalKValueException(k);
		else map.put(item, X-k);
	}

	@Override
	public int getCountForItem(T item) {
		Integer X;
		try{
			X = map.get(item);
			return X;
		}
		catch(Exception exp){
			return 0;
		}
	}

	@Override
	public void addAll(Collection<T> items) {
		for(T i: items) {
			addItem(i);
		}
	}

	@Override
	public void clear() {
		map.clear();		
	}

	@Override
	public Set<T> getItemsSet() {
		Set<T> set = new HashSet<T>();
		for (T item : map.keySet()) {
			if(getCountForItem(item)!=0)
				set.add(item);
		}
		return set;
	}

	@Override
	public void update(IHistogram<T> anotherHistogram) {	
		T x;
		for (Iterator<T> it = anotherHistogram.iterator(); it.hasNext(); ) {
			x = it.next();
			for(int i = 0; i<anotherHistogram.getCountForItem(x); i++) {
				addItem(x);
			}
		}
	}
}
