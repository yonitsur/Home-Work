package il.ac.tau.cs.sw1.hw3;

import java.util.Arrays;

public class ArrayUtils {

	public static int[][] transposeMatrix(int[][] m) {
		
		if (m.length == 0)	
			return m;
		int[][] trans = new int[m[0].length][m.length]; 
		for(int i =0; i<m.length; i++) 
			for(int j=0; j<m[0].length; j++)
				trans[j][i] = m[i][j];
		return trans; 
	}

	public static int[] shiftArrayCyclic(int[] array, int move, char direction) {
		if(move==0 || array.length==0 || (direction!='R' && direction!='L')) 
			return array;
		int[] shift = new int[array.length];
		move = move % array.length;
		if (move<0) {
			direction = (direction=='R'?'L':'R');
			move *= -1;
			}
		if (direction =='L')
			move = array.length - move;
		for(int i=0; i<array.length; i++)
				shift[(i+move)%array.length] = array[i];
		array = shift;
		return array;
		}
		

	public static int alternateSum(int[] array) {
		int maxSum = 0;
		int tmp;
		for (int i=0; i<array.length; i++) {
			tmp=0;
			for(int j = i; j<array.length; j++) {
				if ((j-i)%2 == 0) 
					tmp+=array[j];
				else 
					tmp-=array[j];
				if (tmp>maxSum)
					maxSum=tmp;
			}
		}
		return maxSum;
				
	}
	
	public static int findPath(int[][] m, int i, int j, int k) {		
		// I don't know.....
		return 0;
		
	}
	
}
