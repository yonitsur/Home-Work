package il.ac.tau.cs.sw1.ex8.wordsRank;

import java.util.Comparator;

import il.ac.tau.cs.sw1.ex8.wordsRank.RankedWord.rankType;


/**************************************
 *  Add your code to this class !!!   *
 **************************************/

class RankedWordComparator implements Comparator<RankedWord>{
	private rankType Type;
	public RankedWordComparator(rankType cType) {
		Type = cType;
	}
	
	@Override
	public int compare(RankedWord o1, RankedWord o2) {
		if(o1.getRankByType(Type)== o2.getRankByType(Type))
			return 0; 
		else if(o1.getRankByType(Type) > o2.getRankByType(Type))
			return 1;
		else return -1;
	}	
}
