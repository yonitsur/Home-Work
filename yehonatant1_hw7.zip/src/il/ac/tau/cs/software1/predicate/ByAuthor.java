package il.ac.tau.cs.software1.predicate;

public class ByAuthor implements Predicate<Book> {
	private char ot;

	public ByAuthor(char letter) { // Q2
		ot = letter;
	}

	@Override
	public boolean test(Book book) { // Q2
		if(Character.toLowerCase(book.getAuthor().charAt(0))==ot)
			return true;
		return false;
	}
}