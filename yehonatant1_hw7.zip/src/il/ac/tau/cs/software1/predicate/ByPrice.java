package il.ac.tau.cs.software1.predicate;

public class ByPrice implements Predicate<SmartPhone>{
	private double maxP;
	
	public ByPrice(double maxPrice) { // Q2
		maxP = maxPrice;
	}

	@Override
	public boolean test(SmartPhone phone) { // Q2
		if(phone.getPrice() <= maxP)
			return true;
		return false;
	}
}
