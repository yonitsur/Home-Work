package il.ac.tau.cs.software1.bufferedIO;

import java.io.FileWriter;
import java.io.IOException;
import java.io.BufferedWriter;

/**************************************
 *  Add your code to this class !!!   *
 **************************************/

public class MyBufferedWriter implements IBufferedWriter{
	private FileWriter fw;
	private int size;
	private char[] xxx;

	public MyBufferedWriter(FileWriter fWriter, int bufferSize){
		fw = fWriter;
		size = bufferSize;
		xxx = new char[size];
	}

	
	@Override
	public void write(String str) throws IOException {
		int i=0;
		int j=0;
		
		while(i<str.length()) {
			xxx[j] = str.charAt(i);
			j++;
			if(j==size) {
				fw.write(xxx);
				xxx = new char[size];
				j=0;
			}
			i++;
		}
		char[] yyy = new char[j];
		for(int k=0; k<j ; k++) {
			yyy[k]=xxx[k];
		}
		fw.write(yyy);
	}

	@Override
	public void close() throws IOException {
		fw.close();
	}

}