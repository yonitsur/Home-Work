package il.ac.tau.cs.software1.ip;

public class IPAddressInt implements IPAddress {

	private int[] add = new int[4];
	private int ip;

	IPAddressInt(int address) {
		ip = address;
		String str= Integer.toBinaryString(address);
		String str0=new String();
		String str1=new String();
		String str2=new String();
		String str3=new String();
		for(int i=0; i<8; i++) {
			str0+=str.charAt(i);
			str1+=str.charAt(i+8);
			str2+=str.charAt(i+16);
			str3+=str.charAt(i+24);
		}
		add[0] = Integer.parseInt(str0,2);
		add[1]= Integer.parseInt(str1,2);
		add[2]= Integer.parseInt(str2,2);
		add[3]= Integer.parseInt(str3,2);
	}

	@Override
	public String toString() {

		return String.valueOf(add[0])+'.'+String.valueOf(add[1])+'.'+String.valueOf(add[2])+'.'+String.valueOf(add[3]);
		
		
		/*
		String str= new String();
		
		int a= 255;
		int b = 65280;
		int c=16711680;
		int d= -16777216;
		
		int oct0= ip&a;
		int oct1= ((ip&b)>>8);
		int oct2 = ((ip&c)>>16);
		int oct3 = ((ip&d)>>24);
		
		if (oct0<0) oct0+=256;
		if (oct1<0) oct1+=256;
		if (oct2<0) oct2+=256;
		if (oct3<0) oct3+=256;
		
		str=String.valueOf(oct3)+'.'+String.valueOf(oct2)+'.'+String.valueOf(oct1)+'.'+String.valueOf(oct0);
		return str;*/
		
	}

	@Override
	public boolean equals(IPAddress other) {
		if(this.toString().equals(other.toString()))
			return true;
		return false;
	}

	@Override
	public int getOctet(int index) {
		
		return add[index];
	}

	@Override
	public boolean isPrivateNetwork(){
		if(add[0]==10) 
			return true;
		if(add[0]==172 && add[1]>=16 && add[1]<=31)
			return true;
		if(add[0]==192 && add[1]==168)
			return true;
		if(add[0]==169 && add[1]==254)
			return true;
		return false;
	}
	
}
