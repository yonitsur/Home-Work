package il.ac.tau.cs.software1.ip;

public class IPAddressShort implements IPAddress {
	private short[] ip;


	IPAddressShort(short[] address) {
		ip=address;
	}

	@Override
	public String toString() {
		String str= new String();
		for(int i=0; i<ip.length-1; i++) {
			str+=ip[i];
			str+='.';
		}
		str+=ip[ip.length-1];
		return str;
	}

	@Override
	public boolean equals(IPAddress other) {
		if(this.toString().equals(other.toString()))
			return true;
		return false;
	}

	@Override
	public int getOctet(int index) {
		return ip[index];
	}

	@Override
	public boolean isPrivateNetwork(){
		if(ip[0]==10) 
			return true;
		if(ip[0]==172 && ip[1]>=16 && ip[1]<=31)
			return true;
		if(ip[0]==192 && ip[1]==168)
			return true;
		if(ip[0]==169 && ip[1]==254)
			return true;
		return false;
	}
	
}
